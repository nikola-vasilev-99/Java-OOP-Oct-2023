package Unit1_WorkingWithAbstraction.EX.EX4_TrafficLights;

public enum Color {
    GREEN,
    YELLOW,
    RED;
}
