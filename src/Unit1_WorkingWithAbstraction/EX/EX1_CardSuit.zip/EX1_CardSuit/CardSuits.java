package Unit1_WorkingWithAbstraction.EX.EX1_CardSuit;

public enum CardSuits {
    CLUBS, DIAMONDS, HEARTS, SPADES;
}
