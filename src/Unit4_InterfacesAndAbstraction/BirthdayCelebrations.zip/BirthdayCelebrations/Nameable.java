package BirthdayCelebrations;

public interface Nameable {
    String getName();
    int getAge();
}
