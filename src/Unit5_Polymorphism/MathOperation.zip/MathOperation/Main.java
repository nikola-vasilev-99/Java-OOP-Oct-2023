package MathOperation;

public class Main {
    public static void main(String[] args) {
        //MathOperation mathOperation = new MathOperation(); -> това вече е ненужно, поради статичните методи
        System.out.println(MathOperation.add(1, 2));
        System.out.println(MathOperation.add(1, 2, 3));
        System.out.println(MathOperation.add(1, 2, 3, 4));
        // в случая можем да направим методите в класа MathOperation
        // статични и по този начин няма да се налага да създаваме нова инстанция
        // (MathOperation mo = new MathOperation();), а ще можем директно да си извикаме метода add
        // върху MathOperation

    }
}
