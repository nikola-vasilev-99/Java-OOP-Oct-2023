package EX4_RandomArrayList;

public class Main {
    public static void main(String[] args) {
        RandomArrayList list = new RandomArrayList();
        list.getRandomElement();
    }
}
